#ifndef __serviceapp_H__
#define __serviceapp_H__

#include <dlog.h>

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "serviceapp"


#endif /* __serviceapp_H__ */
